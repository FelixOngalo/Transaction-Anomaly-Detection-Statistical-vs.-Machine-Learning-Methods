library(readr)
source("R/cleaning.R")

raw   <- read_csv("data/raw/transactions.csv", show_col_types = FALSE)
clean <- clean_transactions(raw)

cat("Transactions:", nrow(clean), "\n")
if ("is_anomaly" %in% names(clean)) {
  cat("Labeled anomalies:", sum(clean$is_anomaly, na.rm = TRUE),
      sprintf("(%.2f%%)", 100 * mean(clean$is_anomaly, na.rm = TRUE)), "\n")
}

saveRDS(clean, "data/clean/transactions_clean.rds")
