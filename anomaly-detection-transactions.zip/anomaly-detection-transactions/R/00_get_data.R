# Data for this project: transaction-level data with known normal vs.
# anomalous patterns.
#
# OPTION A (real data): reuse "Online Retail II" (same dataset used
#   across several projects in this portfolio). Real retail data has
#   genuine outliers (data entry errors, bulk wholesale orders, returns)
#   but no labeled "ground truth" of which ones are actually fraud --
#   good for practicing UNSUPERVISED anomaly detection, where you don't
#   know the answer in advance.
#     https://archive.ics.uci.edu/dataset/502/online+retail+ii
#   Place at data/raw/online_retail_II.xlsx
#
# OPTION B (runs immediately, no download): simulated transactions with
#   a known, labeled set of injected anomalies (unusually large amounts,
#   odd hours, impossible velocity) -- lets you validate detection
#   methods against ground truth before trusting them on real data where
#   you don't have labels.
#   Run R/00_simulate_data.R.

message("Use Option A (download Online Retail II) or Option B (source('R/00_simulate_data.R')).")
