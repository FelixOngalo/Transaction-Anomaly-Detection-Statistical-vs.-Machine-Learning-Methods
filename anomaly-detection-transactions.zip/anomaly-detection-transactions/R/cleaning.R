library(dplyr)
library(janitor)
library(lubridate)

clean_transactions <- function(raw) {
  raw |>
    clean_names() |>
    mutate(
      timestamp = as_datetime(timestamp),
      amount    = as.numeric(amount),
      hour      = as.integer(hour)
    ) |>
    filter(!is.na(amount), amount > 0)
}
