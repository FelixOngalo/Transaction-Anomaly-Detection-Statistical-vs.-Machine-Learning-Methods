# Simulate 20,000 "normal" card transactions plus a small set of
# DELIBERATELY injected anomalies with known labels, so detection
# methods can be validated against ground truth -- real fraud data is
# almost never labeled this cleanly, so this is a controlled way to
# learn whether a method actually works before applying it blind.

library(dplyr)
library(lubridate)
library(readr)

set.seed(7)

n_normal <- 20000
n_customers <- 500

# Normal transactions: amounts log-normally distributed (typical for
# spend data -- many small purchases, a long right tail of bigger ones),
# concentrated in daytime hours, one merchant category per transaction.
categories <- c("groceries", "restaurants", "fuel", "retail", "utilities", "entertainment")

normal_tx <- tibble(
  transaction_id = paste0("T", seq_len(n_normal)),
  customer_id    = sample(seq_len(n_customers), n_normal, replace = TRUE),
  amount         = round(rlnorm(n_normal, meanlog = 3.2, sdlog = 0.9), 2),
  hour           = round(pmin(pmax(rnorm(n_normal, mean = 14, sd = 4), 0), 23)),
  category       = sample(categories, n_normal, replace = TRUE),
  timestamp      = as_datetime("2026-01-01") + days(sample(0:89, n_normal, replace = TRUE)) + hours(round(pmin(pmax(rnorm(n_normal, mean = 14, sd = 4), 0), 23))),
  is_anomaly     = FALSE,
  anomaly_type   = NA_character_
)

# Injected anomalies, by type -- each represents a DIFFERENT real-world
# fraud/error pattern, deliberately distinct so detection methods have
# to actually generalize, not just spot one trick.
n_large_amount <- 40   # unusually large purchase for that customer
n_odd_hour     <- 35   # purchase at an unusual hour (e.g. 3am)
n_velocity     <- 25   # several transactions for the same customer within minutes (card testing)

large_amount_tx <- tibble(
  transaction_id = paste0("A_large_", seq_len(n_large_amount)),
  customer_id    = sample(seq_len(n_customers), n_large_amount, replace = TRUE),
  amount         = round(runif(n_large_amount, 2000, 8000), 2),   # far beyond normal range
  hour           = sample(0:23, n_large_amount, replace = TRUE),
  category       = sample(categories, n_large_amount, replace = TRUE),
  timestamp      = as_datetime("2026-01-01") + days(sample(0:89, n_large_amount, replace = TRUE)) + hours(sample(0:23, n_large_amount, replace = TRUE)),
  is_anomaly     = TRUE,
  anomaly_type   = "unusually_large_amount"
)

odd_hour_tx <- tibble(
  transaction_id = paste0("A_hour_", seq_len(n_odd_hour)),
  customer_id    = sample(seq_len(n_customers), n_odd_hour, replace = TRUE),
  amount         = round(rlnorm(n_odd_hour, meanlog = 3.2, sdlog = 0.9), 2),
  hour           = sample(c(1, 2, 3, 4), n_odd_hour, replace = TRUE),   # middle of the night
  category       = sample(categories, n_odd_hour, replace = TRUE),
  timestamp      = as_datetime("2026-01-01") + days(sample(0:89, n_odd_hour, replace = TRUE)) + hours(sample(c(1,2,3,4), n_odd_hour, replace = TRUE)),
  is_anomaly     = TRUE,
  anomaly_type   = "unusual_hour"
)

# Velocity fraud: pick a few customers, give each a burst of 4-6
# transactions within a short window -- a classic card-testing pattern.
velocity_customers <- sample(seq_len(n_customers), ceiling(n_velocity / 5))
velocity_tx <- purrr::map_dfr(velocity_customers, function(cid) {
  base_time <- as_datetime("2026-01-01") + days(sample(0:89, 1)) + hours(sample(0:23, 1))
  n_burst <- sample(4:6, 1)
  tibble(
    transaction_id = paste0("A_velocity_", cid, "_", seq_len(n_burst)),
    customer_id    = cid,
    amount         = round(runif(n_burst, 1, 50), 2),   # small "testing" amounts
    hour           = hour(base_time),
    category       = sample(categories, n_burst, replace = TRUE),
    timestamp      = base_time + minutes(sample(0:10, n_burst, replace = TRUE)),
    is_anomaly     = TRUE,
    anomaly_type   = "velocity_burst"
  )
})

all_tx <- bind_rows(normal_tx, large_amount_tx, odd_hour_tx, velocity_tx) |>
  arrange(timestamp)

dir.create("data/raw", showWarnings = FALSE, recursive = TRUE)
write_csv(all_tx, "data/raw/transactions.csv")
message("Simulated ", nrow(all_tx), " transactions (", sum(all_tx$is_anomaly), " labeled anomalies).")
message("Anomaly types: ", paste(unique(na.omit(all_tx$anomaly_type)), collapse = ", "))
