# Reusable functions for transaction anomaly detection. Two methods are
# implemented deliberately, not just one, because they catch different
# things and a real fraud-analytics workflow typically combines both:
#
#  1. A simple STATISTICAL method (z-scores on amount, per customer) --
#     transparent, explainable to a non-technical reviewer, catches
#     "this is way outside what THIS customer normally spends."
#  2. ISOLATION FOREST -- a machine learning method that looks at
#     multiple features jointly, catches combinations that are unusual
#     together even if no single feature is extreme on its own.

library(dplyr)
library(lubridate)

#' Build detection features per transaction, including PER-CUSTOMER
#' behavioral context -- not just the raw transaction, since "$500 is
#' huge" only means something relative to what a given customer
#' usually spends.
#'
#' @param tx Cleaned transaction data (transaction_id, customer_id,
#'   amount, hour, timestamp, category).
#' @return A tibble with the original columns plus derived features:
#'   customer_mean_amount, customer_sd_amount, amount_zscore,
#'   minutes_since_prev_tx (same customer).
build_features <- function(tx) {
  customer_stats <- tx |>
    group_by(customer_id) |>
    summarise(
      customer_mean_amount = mean(amount),
      customer_sd_amount   = sd(amount),
      .groups = "drop"
    )

  tx |>
    left_join(customer_stats, by = "customer_id") |>
    group_by(customer_id) |>
    arrange(timestamp, .by_group = TRUE) |>
    mutate(
      # A customer with only 1-2 transactions has an unreliable/zero SD;
      # guard against dividing by zero or near-zero, which would make
      # a totally ordinary amount look like an extreme z-score.
      amount_zscore = if_else(
        is.na(customer_sd_amount) | customer_sd_amount < 1,
        0,
        (amount - customer_mean_amount) / customer_sd_amount
      ),
      minutes_since_prev_tx = as.numeric(difftime(timestamp, lag(timestamp), units = "mins"))
    ) |>
    ungroup() |>
    mutate(minutes_since_prev_tx = coalesce(minutes_since_prev_tx, 9999))   # first tx for a customer: no "previous" to compare
}

#' Method 1: flag transactions with an extreme per-customer z-score on
#' amount. Simple, fast, and fully explainable -- "this transaction is
#' N standard deviations above what this customer normally spends" is
#' a sentence a fraud reviewer or auditor can act on directly, which
#' matters as much as raw detection power in many real settings.
#'
#' @param features Output of build_features().
#' @param z_threshold Flag transactions with |z-score| above this.
#' @return The input tibble with an added `flagged_zscore` logical column.
flag_by_zscore <- function(features, z_threshold = 3) {
  features |> mutate(flagged_zscore = abs(amount_zscore) > z_threshold)
}

#' Method 2: Isolation Forest. The core idea: anomalies are "few and
#' different," so they're easier to ISOLATE with random splits than
#' normal points are. The algorithm builds many random decision trees;
#' a point that gets separated from everything else in very few splits
#' (a short average path length across all the trees) is scored as more
#' anomalous. Unlike the z-score method, this considers several
#' features TOGETHER, so it can catch a combination that's unusual even
#' if no single feature crosses an extreme threshold on its own.
#'
#' @param features Output of build_features().
#' @param feature_cols Which columns to feed the model.
#' @param contamination Expected proportion of anomalies (used only to
#'   pick a score cutoff for flagging -- the model itself doesn't need
#'   labels to be fit).
#' @return The input tibble with added `iso_score` (0-1, higher = more
#'   anomalous) and `flagged_iforest` logical columns.
flag_by_isolation_forest <- function(features, feature_cols = c("amount", "hour", "minutes_since_prev_tx"),
                                     contamination = 0.01) {
  library(isotree)

  model_data <- features |> select(all_of(feature_cols))

  model <- isolation.forest(model_data, ntrees = 200, sample_size = 256, seed = 42)
  scores <- predict(model, model_data)   # higher score = more anomalous

  cutoff <- quantile(scores, probs = 1 - contamination)

  features |>
    mutate(iso_score = scores, flagged_iforest = iso_score > cutoff)
}

#' Evaluate flagged results against known labels (only possible with
#' the simulated dataset, which has ground truth -- real fraud data
#' almost never does). Precision answers "of what we flagged, how much
#' was really anomalous" (false-alarm rate); recall answers "of all the
#' real anomalies, how many did we catch" (miss rate). The two trade
#' off against each other, which is why BOTH are reported, not just one.
#'
#' @param results A tibble with is_anomaly (truth) and a flagged_* column.
#' @param flag_col Name of the logical column with the method's flags.
#' @return A one-row tibble of precision, recall, f1, and counts.
evaluate_detection <- function(results, flag_col) {
  flagged <- results[[flag_col]]
  truth   <- results$is_anomaly

  tp <- sum(flagged & truth)
  fp <- sum(flagged & !truth)
  fn <- sum(!flagged & truth)

  precision <- if ((tp + fp) > 0) tp / (tp + fp) else NA_real_
  recall    <- if ((tp + fn) > 0) tp / (tp + fn) else NA_real_
  f1        <- if (!is.na(precision) && !is.na(recall) && (precision + recall) > 0) {
    2 * precision * recall / (precision + recall)
  } else NA_real_

  tibble::tibble(
    method = flag_col, true_positives = tp, false_positives = fp, false_negatives = fn,
    precision = precision, recall = recall, f1 = f1
  )
}
