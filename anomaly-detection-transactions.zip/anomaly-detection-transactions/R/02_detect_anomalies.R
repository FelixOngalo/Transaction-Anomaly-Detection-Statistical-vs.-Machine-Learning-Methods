library(dplyr)
source("R/anomaly_functions.R")

tx <- readRDS("data/clean/transactions_clean.rds")

features <- build_features(tx)

results <- features |>
  flag_by_zscore(z_threshold = 3) |>
  flag_by_isolation_forest(contamination = 0.01)

cat("Flagged by z-score method:       ", sum(results$flagged_zscore), "\n")
cat("Flagged by isolation forest:      ", sum(results$flagged_iforest), "\n")
cat("Flagged by BOTH methods:          ", sum(results$flagged_zscore & results$flagged_iforest), "\n")

# Validate against ground truth -- only meaningful for the simulated
# dataset, which has known labels. Real fraud data wouldn't have this
# step available, which is exactly why practicing it here matters.
if ("is_anomaly" %in% names(results)) {
  eval_results <- bind_rows(
    evaluate_detection(results, "flagged_zscore"),
    evaluate_detection(results, "flagged_iforest")
  )
  cat("\n=== Evaluation against known labels ===\n")
  print(eval_results)
  saveRDS(eval_results, "data/clean/evaluation.rds")
}

saveRDS(results, "data/clean/detection_results.rds")
