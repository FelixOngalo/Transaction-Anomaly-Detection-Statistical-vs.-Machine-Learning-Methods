# Transaction Anomaly Detection: Statistical vs. Machine Learning Methods

**Question:** *(fill in)* Which transactions look unusual enough to warrant review, and how do statistical and machine-learning detection methods compare on precision, recall, and the specific patterns each one catches?

**Key findings:** *(fill in after running; precision/recall for each method, and your recommendation)*

**Tools:** R, `isotree` (Isolation Forest), tidyverse, Quarto

## Why this project

A new technique for this portfolio: **anomaly detection**, applied to a fraud/outlier-transaction use case. Two methods are implemented deliberately, not just one — a simple, fully explainable statistical method (per-customer z-scores) and a machine-learning method (Isolation Forest) that considers multiple features jointly. They catch genuinely different things, which is the point: a real fraud-analytics workflow typically layers both rather than picking a single "best" method.

## Reproduce

1. Get data: run `source("R/00_simulate_data.R")` for a dataset with deliberately injected, labeled anomalies (unusually large amounts, odd-hour purchases, and rapid-fire "velocity" bursts) — lets both methods be validated against known ground truth, **or** substitute the real Online Retail II dataset (see `R/00_get_data.R`) for unsupervised practice without labels.
2. `install.packages(c("tidyverse", "janitor", "isotree", "scales", "quarto"))`
3. Run in order:
   - `R/01_clean.R`
   - `R/02_detect_anomalies.R` (builds features, runs both detection methods, evaluates against labels if present)
   - Render `reports/report.qmd`

## Method in brief

1. **Engineer per-customer features**, not just raw transaction values — "$500 is huge" only means something relative to what a *specific* customer normally spends, so every feature is computed in that context (see `build_features()` in `R/anomaly_functions.R`, including a guard against unreliable standard deviations for customers with very few transactions).
2. **Method 1 — per-customer z-score**: flag transactions far from a customer's personal average spend. Simple, transparent, and directly explainable to a non-technical reviewer, but only considers one dimension at a time.
3. **Method 2 — Isolation Forest**: a machine-learning method built on the idea that anomalies are "few and different," so they're isolated by random data splits in fewer steps than normal points are. Considers several features jointly, catching combinations (e.g. a mildly elevated amount + an odd hour + rapid timing) that no single-feature rule would flag.
4. **Validate against known labels** (simulated data only — real fraud data almost never comes pre-labeled): precision (of what we flagged, how much was real) and recall (of all real anomalies, how many we caught), reported together since they trade off against each other.
5. **Compare where the methods agree and diverge**, since the overlap (or lack of it) is itself informative about each method's blind spots.

## Key concepts

| Concept | Plain-English meaning |
|---|---|
| Z-score | How many standard deviations a value is from the mean — here, computed per customer, not globally |
| Isolation Forest | An ML method that scores points as anomalous based on how few random splits it takes to separate them from the rest of the data |
| Precision | Of everything flagged, the share that was a real anomaly — low precision means wasted reviewer time |
| Recall | Of all real anomalies, the share that were caught — low recall means real problems slip through |
| Precision/recall trade-off | Making a method stricter raises precision but lowers recall, and vice versa — there's no setting that maximizes both |
| Contamination | The assumed proportion of anomalies in the data, used to pick a score cutoff for Isolation Forest |

## Project structure

```
R/00_get_data.R           real-data source notes
R/00_simulate_data.R      generates labeled transactions with 3 distinct injected anomaly types
R/cleaning.R                cleaning function
R/01_clean.R                 run cleaning
R/anomaly_functions.R         feature engineering, z-score method, Isolation Forest method, evaluation (heavily commented)
R/02_detect_anomalies.R       run both detection methods, evaluate against labels
reports/report.qmd            full write-up: method comparison, validation, overlap analysis, recommendation
```

## Limitations

*(fill in — see the report's own Limitations section: simulated anomalies are deliberately distinct for teaching purposes; real fraud is subtler and adaptive)*
